import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BankingApp {
    public static void main(String[] args) {
        // Set the path to the chromedriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\z00497315\\.p2\\chromedriver-win64");

        // Create a new instance of the ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Launch the banking application
        driver.get("https://www.examplebank.com");
        
        // Enter username and password
        WebElement username = driver.findElement(By.id("username"));
        WebElement password = driver.findElement(By.id("password"));
        username.sendKeys("your_username");
        password.sendKeys("your_password");

        // Click on the login button
        WebElement loginButton = driver.findElement(By.id("loginButton"));
        loginButton.click();

        // Verify successful login
        WebElement welcomeMessage = driver.findElement(By.id("welcomeMessage"));
        String message = welcomeMessage.getText();
        if (message.equals("Welcome, your_username!")) {
            System.out.println("Login successful");
        } else {
            System.out.println("Login failed");
        }

        // Close the browser
        driver.quit();
    }
}
